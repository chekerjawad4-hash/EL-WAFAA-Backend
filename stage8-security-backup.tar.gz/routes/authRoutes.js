const express = require("express");
const router = express.Router();

const {
    createUser,
    loginUser
} = require("../database/users");

router.post("/register", (req, res) => {

    const { username, email, password } = req.body;

    const result = createUser(
        username,
        email,
        password
    );

    res.json(result);

});

router.post("/login", (req, res) => {

    const { email, password } = req.body;

    const result = loginUser(
        email,
        password
    );

    res.json(result);

});

module.exports = router;
